//
//  ViewController.swift
//  Scouting Application
//
//  Created by Vrishab Madduri on 10/30/17.
//  Copyright © 2017 Vrishab Madduri. All rights reserved.
//
import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var hangControl: UISegmentedControl!
    @IBOutlet weak var matchInput: UITextField!
    @IBOutlet weak var teamInput: UITextField!
    @IBOutlet weak var matchColor: UISegmentedControl!
    @IBOutlet weak var scoreInput: UITextField!
    @IBOutlet weak var commentInput: UITextField!
    @IBOutlet weak var autogearInput: UITextField!
    @IBOutlet weak var autoballInput: UITextField!
    @IBOutlet weak var telegearInput: UITextField!
    @IBOutlet weak var teleballInput: UITextField!
    @IBOutlet weak var endgearInput: UITextField!
    @IBOutlet weak var endballInput: UITextField!
    @IBOutlet weak var autogearStepper: UIStepper!
    @IBOutlet weak var autoballStepper: UIStepper!
    @IBOutlet weak var telegearStepper: UIStepper!
    @IBOutlet weak var teleballStepper: UIStepper!
    @IBOutlet weak var endgearStepper: UIStepper!
    @IBOutlet weak var endballStepper: UIStepper!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    @IBAction func submit(_ sender: Any) {
        GlobalState.hang = hangControl.titleForSegment(at:  hangControl.selectedSegmentIndex) ?? "No"
        GlobalState.color = matchColor.titleForSegment(at:  matchColor.selectedSegmentIndex) ?? "No"
        GlobalState.match = Int(matchInput.text ?? "0") ?? -1
        GlobalState.team = Int(teamInput.text ?? "0") ?? -1
        GlobalState.score = Int(scoreInput.text ?? "0") ?? -1
        GlobalState.comment = String(commentInput.text!)
        
        GlobalState.autogear = Double(autogearInput.text ?? "-1") ?? -1
        GlobalState.autoball = Double(autoballInput.text ?? "-1") ?? -1
        GlobalState.telegear = Double(telegearInput.text ?? "-1") ?? -1
        GlobalState.teleball = Double(teleballInput.text ?? "-1") ?? -1
        GlobalState.endgear = Double(endgearInput.text ?? "-1") ?? -1
        GlobalState.endball = Double(endballInput.text ?? "-1") ?? -1
        
        self.performSegue(withIdentifier: "SubmitSegue", sender: self)
    }
    @IBAction func autostepvalueChanged(_ sender: UIStepper) {
        GlobalState.autogear = Double(autogearInput.text ?? "0") ?? 0
        autogearInput.text = String(sender.value + GlobalState.autogear)
        GlobalState.autogear = Double(autogearInput.text ?? "0") ?? 0
        
        sender.value = 0
    }

    @IBAction func autoballstepvalueChanged(_ sender: UIStepper) {
        GlobalState.autoball = Double(autoballInput.text ?? "0") ?? 0
        autoballInput.text = String(sender.value + GlobalState.autoball)
        GlobalState.autoball = Double(autoballInput.text ?? "0") ?? 0
        
        sender.value = 0
    
    }
    
    @IBAction func telegearstepvalueChanged(_ sender: UIStepper) {
         GlobalState.telegear = Double(telegearInput.text ?? "0") ?? 0
         telegearInput.text = String(sender.value + GlobalState.telegear)
         GlobalState.telegear = Double(telegearInput.text ?? "0") ?? 0
        
        sender.value = 0
        
    }
    
    @IBAction func teleballstepvalueChanged(_ sender: UIStepper) {
    GlobalState.teleball = Double(teleballInput.text ?? "0") ?? 0
    teleballInput.text = String(sender.value + GlobalState.teleball)
    GlobalState.teleball = Double(teleballInput.text ?? "0") ?? 0
        sender.value = 0
    }
    
    @IBAction func endgearstepvalueChanged(_ sender: UIStepper) {
    GlobalState.endgear = Double(endgearInput.text ?? "0") ?? 0
    endgearInput.text = String(sender.value + GlobalState.endgear)
    GlobalState.endgear = Double(endgearInput.text ?? "0") ?? 0
        sender.value = 0
    
    }

    @IBAction func endballstepvalueChanged(_ sender: UIStepper) {
        GlobalState.endball = Double(endballInput.text ?? "0") ?? 0
        endballInput.text = String(sender.value + GlobalState.endball)
        GlobalState.endball = Double(endballInput.text ?? "0") ?? 0
        sender.value = 0
    }
    
}

