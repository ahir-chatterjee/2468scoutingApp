//
//  GlobalState.swift
//  Scouting Application
//
//  Created by Vrishab Madduri on 11/15/17.
//  Copyright © 2017 Vrishab Madduri. All rights reserved.
//

import Foundation

public class GlobalState {
    static var hang = "Unknown"
    static var match = -1
    static var team = -1
    static var color = "Unknown"
    static var score = -1
    static var comment = "Unknown"
    static var autogear = 0.0
    static var autoball = 0.0
    static var telegear = 0.0
    static var teleball = 0.0
    static var endgear = 0.0
    static var endball = 0.0
}
