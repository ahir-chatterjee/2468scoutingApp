//
//  WebInputViewController.swift
//  Scouting Application
//
//  Created by Vrishab Madduri on 11/15/17.
//  Copyright © 2017 Vrishab Madduri. All rights reserved.
//

import Foundation
import UIKit

class WebInputViewController: UIViewController {
    @IBOutlet weak var hangLabel: UILabel!
    @IBOutlet weak var matchLabel: UILabel!
    @IBOutlet weak var teamLabel: UILabel!
    @IBOutlet weak var matchcolorLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var commentLabel: UILabel!
    @IBOutlet weak var autogearLabel: UILabel!
    @IBOutlet weak var autoballLabel: UILabel!
    @IBOutlet weak var telegearLabel: UILabel!
    @IBOutlet weak var teleballLabel: UILabel!
    @IBOutlet weak var endgearLabel: UILabel!
    @IBOutlet weak var endballLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        hangLabel.text = "Hang: \(GlobalState.hang)"
        matchLabel.text = "Match #: \(GlobalState.match)"
        teamLabel.text = "Team #: \(GlobalState.team)"
        matchcolorLabel.text = "Alliance Color: \(GlobalState.color)"
        scoreLabel.text = "Score: \(GlobalState.score)"
        commentLabel.text = "Additional Comments: \(GlobalState.comment)"
        autogearLabel.text = "Gears: \(GlobalState.autogear)"
        autoballLabel.text = "Balls: \(GlobalState.autoball)"
         telegearLabel.text = "Gears: \(GlobalState.telegear)"
        teleballLabel.text = "Balls: \(GlobalState.teleball)"
        endgearLabel.text = "Gears: \(GlobalState.endgear)"
        endballLabel.text = "Balls: \(GlobalState.endball)"

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
